﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Text
{
    public class Title : Container
    {
        public Title()
        {
            this.Text = "Le Chaperon Rouge";
        }
    }
}
