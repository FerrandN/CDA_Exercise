﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Text
{
    public class Paragraphe : Container
    {
        public Paragraphe()
        {
            this.Text = "Le Chaperon Rouge vient d'apprendre que sa grand-mère était malade." +
            "Elle décide de traverser la fôrêt pour lui apporter une galette.";
        }
    }
}
