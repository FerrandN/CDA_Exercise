﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Text
{
    public class Chapters : Container
    {
        public Chapters()
        {
            this.Text = "La nouvelle";
        }
    }
}
